#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

float *A;
float *B;
float *C;

void *runner(void *param){
  long int n = (long)(param);
  for(int i=0;i<1000000;i++)
    C[i+n] = A[i+n] + B[i+n];
  pthread_exit(0);
}

int main(){
  long int n = 10000000;
  A = (float *)malloc(n * sizeof(float));
  B = (float *)malloc(n * sizeof(float));
  C = (float *)malloc(n * sizeof(float));

  pthread_t worker[10];
  
  for(int i = 0; i<10; i++){
    long int range = i * 1000000;
    pthread_create(&worker[i], NULL, runner, (void *)range);
  }
  
  for(int i = 0;i<10;i++)
    pthread_join(worker[i],NULL);
  
  printf("\nDone!");
  free(A);
  free(B);
  free(C);
  return 0;
}
