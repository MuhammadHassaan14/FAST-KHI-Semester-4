// k232001 - Muzammil
#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>

volatile sig_atomic_t paused = 0;

void handle_sigint(int signum){
    paused = 1;
    printf("\nTimer paused.\n");
}

void handle_sigtstp(int signum){
    paused = 0;
    printf("\nTimer resumed.\n");
}

int main(){
    signal(SIGINT, handle_sigint);
    signal(SIGTSTP, handle_sigtstp);
    int i = 10;
    while(i > 0) {
        if(!paused) {
            printf("Counting: %d\n", i);
            i--;
        }
        sleep(1);
    }
    printf("Countdown complete.\n");
    return 0;
}
