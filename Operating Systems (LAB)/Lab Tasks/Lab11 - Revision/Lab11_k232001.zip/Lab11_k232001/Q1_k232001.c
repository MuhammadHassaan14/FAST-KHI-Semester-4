// k232001 - Muzammil
#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<stdlib.h>

int n;
int *array;

void init_array(int *arr, int n){
    for(int i=0; i<n; i++) 
        arr[i] = rand() % 100;
}

void sort(int *arr, int left, int right){
    for(int i=left; i<right; i++){
        for(int j=i+1; j<=right; j++){
            if(arr[i] > arr[j]){
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

void* runner(void* args){
    int part = *(int*)args;
    int mid = n/2;
    if(part == 0) 
        sort(array, 0, mid-1);
    else 
        sort(array, mid, n-1);
    pthread_exit(0);
}

void merge(){
    int *temp = malloc(sizeof(int)*n);
    int i=0, j=n/2, k=0;
    while(i<n/2 && j<n){
        if(array[i] < array[j]) 
            temp[k++] = array[i++];
        else 
            temp[k++] = array[j++];
    }

    while(i<n/2) 
        temp[k++] = array[i++];

    while(j<n) 
        temp[k++] = array[j++];

    for(i=0; i<n; i++) 
        array[i] = temp[i];
    free(temp);
}

int main() {
    pthread_t t1, t2;
    printf("Enter size for array: ");
    scanf("%d", &n);
    array = malloc(sizeof(int)*n);
    init_array(array, n);

    int part1 = 0, part2 = 1;
    pthread_create(&t1,NULL,runner,&part1);
    pthread_create(&t2,NULL,runner,&part2);
    pthread_join(t1,NULL);
    pthread_join(t2,NULL);

    merge();
    printf("Sorted array: ");
    for(int i=0; i<n; i++) 
        printf("%d ", array[i]);
    printf("\n");
    free(array);
    return 0;
}
