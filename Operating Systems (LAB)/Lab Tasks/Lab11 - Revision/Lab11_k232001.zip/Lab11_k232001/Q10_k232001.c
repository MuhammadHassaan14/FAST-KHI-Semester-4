// k232001 - Muzammil
#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

pthread_mutex_t atm;

void* user(void* arg){
    int id = *(int*)arg;
    pthread_mutex_lock(&atm);
    printf("\nUser %d is accessing the ATM..\n", id);
    sleep(2);

    printf("User %d has finished using the ATM.\n", id);
    pthread_mutex_unlock(&atm);
    return NULL;
}
int main(){
    pthread_t users[5];
    int ids[5];

    printf("Starting simulation...\n");
    pthread_mutex_init(&atm, NULL);
    for(int i=0; i<5; i++){
        ids[i] = i + 1;
        pthread_create(&users[i], NULL, user, &ids[i]);
    }

    for(int i=0; i<5; i++)
        pthread_join(users[i], NULL);

    pthread_mutex_destroy(&atm);
    printf("\nSimulation complete.");
    return 0;
}
