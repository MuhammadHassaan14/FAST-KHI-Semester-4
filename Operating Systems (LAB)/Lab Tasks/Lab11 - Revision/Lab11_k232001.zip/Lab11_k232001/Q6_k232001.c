// k232001 - Muzammil
#include<stdio.h>
#include<signal.h>
#include<unistd.h>

volatile sig_atomic_t flag = 0;

void handler(int signum){
    flag = !flag;
}
int main(){
    signal(SIGUSR1, handler);
    while(1){
        if(flag)
            printf("paused by SIGUSR1\n");
        else
            printf("Working...\n");
        sleep(3);
    }
    return 0;
}
