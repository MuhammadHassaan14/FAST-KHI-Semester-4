#include<iostream>
#include<cmath>
using namespace std;

int main(int argv, char *argc[]){
	cout<<"Square root of passed argument is: ";
	cout<<sqrt(atoi(argc[1]))<<endl;

	return 0;
}
