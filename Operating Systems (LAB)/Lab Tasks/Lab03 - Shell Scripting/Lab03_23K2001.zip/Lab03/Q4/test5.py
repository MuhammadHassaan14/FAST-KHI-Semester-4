print("Hello word")
