#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
    pid_t pid1;
    /* fork a child process */
    pid1 = fork();
    if (pid1 < 0) { /* error occurred */
        fprintf(stderr, "Fork # 1 Failed");
        return 1;
    }
    else if (pid1 == 0) { /* child process */
        printf("[p_id: %d | parent_id: %d] This is from the child process.\n", getpid(), getppid());
        pid_t pid2 = fork();
        if (pid2 < 0) { /* error occurred */
            fprintf(stderr, "Fork # 2 Failed");
            return 1;
        }
        else if (pid2 == 0) { /* grandchild process */
            printf("[p_id: %d | parent_id: %d] This is from the grandchild process.\n", getpid(), getppid()); 
        }
        else { /* parent process */
            /* parent will wait for the child to complete */
            wait(NULL);
            printf("[p_id: %d] Grandchild Complete\n", getpid());
        }
    }
    
    else { /* grandparent process */
        /* parent will wait for the child to complete */
        wait(NULL);
        printf("[p_id: %d] Child Complete\n", getpid());
    }
    return 0;
}
