#include <stdio.h>      // printf
#include <stdlib.h>     // exit
#include <fcntl.h>      // shm_open
#include <sys/shm.h>    // shm_open, shm_unlink
#include <sys/stat.h>   // mode constants (0666)
#include <sys/mman.h>   // mmap, PROT_READ, MAP_SHARED, munmap
#include <unistd.h>     // close

int main() {
    const int SIZE = 4096;
    const char *name = "OS";  // shared memory name

    int fd;
    char *ptr;

    // open existing shared memory object
    fd = shm_open(name, O_RDONLY, 0666);

    // map memory object into process address space
    ptr = (char *) mmap(0, SIZE, PROT_READ, MAP_SHARED, fd, 0);

    // read and print content from shared memory
    printf("%s\n", (char *) ptr);

    // good practice: cleanup
    munmap(ptr, SIZE);    // unmap memory
    close(fd);            // close file descriptor
    shm_unlink(name);     // remove shared memory object name

    return 0;
}

