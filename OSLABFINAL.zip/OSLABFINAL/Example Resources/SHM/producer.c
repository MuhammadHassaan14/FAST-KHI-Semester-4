#include <stdio.h>      // printf
#include <stdlib.h>     // exit
#include <fcntl.h>      // shm_open
#include <sys/shm.h>    // shm_open, shm_unlink
#include <sys/stat.h>   // mode constants (0666)
#include <sys/mman.h>   // mmap, PROT_READ, PROT_WRITE, MAP_SHARED
#include <unistd.h>     // ftruncate

int main() {
    const int SIZE = 4096;
    const char *name = "OS";          // shared memory name
    const char *message_0 = "Hello";  // first message
    const char *message_1 = "World!"; // second message

    int fd;       // shared memory file descriptor
    char *ptr;    // pointer to shared memory

    // create shared memory object
    fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    ftruncate(fd, SIZE);  // set shared memory size

    // map memory object into process address space
    ptr = (char *) mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    // write messages to shared memory
    sprintf(ptr, "%s", message_0);
    ptr += strlen(message_0);
    sprintf(ptr, "%s", message_1);
    ptr += strlen(message_1);

    return 0;
}

