#!usr/bin/bash

#     {start..end..step}
for i in {1..10..2}  # No spaces inside {}, correct syntax
do
    echo "Hey!! $i"  
done

