// Ensure thread 1 executes before thread 2
#include<stdio.h>
#include<semaphore.h>
#include<sys/types.h>
#include<pthread.h>

sem_t mutex;

void* runner1(void *args){
  //sem_wait(&mutex);
  printf("Hello ");
  sem_post(&mutex);
}
void* runner2(void *args){
  sem_wait(&mutex);
  printf("World");
  //sem_post(&mutex);
}

int main(){
  pthread_t t1, t2;
  sem_init(&mutex,0,0);
  
  pthread_create(&t1, NULL, runner1, NULL);
  pthread_create(&t2, NULL, runner2, NULL);
  
  pthread_join(t1, NULL);
  pthread_join(t2, NULL);
  
  sem_destroy(&mutex);
  return 0;
}
