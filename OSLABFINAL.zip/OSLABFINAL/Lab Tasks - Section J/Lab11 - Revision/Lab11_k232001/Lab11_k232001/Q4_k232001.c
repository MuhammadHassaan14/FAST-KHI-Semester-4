// k232001 - Muzammil
#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>

void handler(int signum){
    printf("\nSIGINT caught, terminating safely.\n");
    exit(0);
}
int main(){
    signal(SIGINT, handler);
    while(1){
        printf("Running Muzammil's program...\n");
        sleep(2);
    }
    return 0;
}
