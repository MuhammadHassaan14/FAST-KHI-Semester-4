// k232001 - Muzammil
#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<stdlib.h>

int A[3][3], B[3][3], C[3][3];

void* runner(void* args) {
    int row = (int)args;
    for(int i=0; i<3; i++) {
        C[row][i] = 0;
        for(int j=0; j<3; j++) 
            C[row][i] += A[row][j] * B[j][i];
    }
    pthread_exit(0);
}

int main() {
    pthread_t threads[3];

    printf("Enter Matrix A (3x3):\n");
    for(int i=0; i<3; i++) 
        for(int j=0; j<3; j++) 
            scanf("%d", &A[i][j]);

    printf("Enter Matrix B (3x3):\n");
    for(int i=0; i<3; i++) 
        for(int j=0; j<3; j++) 
            scanf("%d", &B[i][j]);

    for(int i=0; i<3; i++)
        pthread_create(&threads[i], NULL, runner, (void *)i);
    
    for(int i=0; i<3; i++) 
        pthread_join(threads[i], NULL);

    printf("Result Matrix C:\n");
    for(int i=0; i<3; i++) {
        for(int j=0; j<3; j++) 
            printf("%d ", C[i][j]);
        printf("\n");
    }
    return 0;
}
