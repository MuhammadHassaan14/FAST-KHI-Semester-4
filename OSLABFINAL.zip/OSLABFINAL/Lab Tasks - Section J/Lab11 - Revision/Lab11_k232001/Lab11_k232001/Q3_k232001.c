// k232001 - Muzammil
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>

//src:    /home/muzammil/Desktop/OS Lab Tasks/Lab10_k232001/Q3TestSrc.txt
//dest:    /home/muzammil/Desktop/OS Lab Tasks/Lab10_k232001/Q3TestDest.txt
int main(){
    char src_path[256], dest_path[256];
    printf("Enter source file path: ");
    gets(src_path);
    printf("Enter destination file path: ");
    gets(dest_path);

    int src = open(src_path, O_RDONLY);
    if(src < 0){
        perror("Error opening file src file: ");
        printf("%s",src_path);
        exit(1);
    }

    int dest = open(dest_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if(dest < 0){
        perror("Error opening file dest file.");
        close(src);
        exit(1);
    }

    char buffer[1024];
    ssize_t bytes;
    while((bytes = read(src, buffer, sizeof(buffer))) > 0){
        if(write(dest, buffer, bytes) != bytes) {
            perror("Error writing to dest file.");
            close(src);
            close(dest);
            exit(1);
        }
    }

    if(bytes < 0) 
        perror("Error reading from src file.");
    
    printf("\nCopying complete!");
    close(src);
    close(dest);
    return 0;
}
