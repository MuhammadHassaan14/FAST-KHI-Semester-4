#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

int AVG, mx, mn;

void *avg(void *param){
  int *arr = (int *)param;
  int n = arr[0];
  int sum = 0;
  for(int i = 1; i<=n; i++)
    sum += arr[i];
  
  AVG = sum/n;
  pthread_exit(0);
}
void *max(void *param){
  int *arr = (int *)param;
  int n = arr[0];
  mx = arr[1];
  for(int i = 2; i<=n; i++){
    if (arr[i] > mx)
            mx= arr[i];
  }
  pthread_exit(0);
}
void *min(void *param){
  int *arr = (int *)param;
  int n = arr[0];
  mn = arr[1];
  for(int i = 2; i<=n; i++){
    if (arr[i] < mn)
            mn = arr[i];
  }
  pthread_exit(0);
}

int main(int argc, char *argv[]){
  int args[argc];
  args[0] = argc - 1;
  for(int i = 1; i<argc; i++)
    args[i] = atoi(argv[i]);
  
  pthread_t worker[3];
  
  pthread_create(&worker[0], NULL, avg, (void *)args);
  pthread_create(&worker[1], NULL, max, (void *)args);
  pthread_create(&worker[2], NULL, min, (void *)args);
  
  for(int i = 0;i<3;i++)
    pthread_join(worker[i],NULL);
  
  printf("\nDone!\n");
  printf("AVG = %d!\n", AVG);
  printf("MAX = %d!\n", mx);
  printf("MIN = %d!\n", mn);
  return 0;
}
