#include<stdio.h>
#include<stdlib.h>

int main(){
  long int n = 10000000;
  float *A = (float *)malloc(n * sizeof(float));
  float *B = (float *)malloc(n * sizeof(float));
  float *C = (float *)malloc(n * sizeof(float));

  for(long int i = 0; i < n; i++){
      A[i] = 1.5;
      B[i] = 1.5;
      C[i] = A[i] + B[i];
  }

  printf("\nDone!");

  free(A);
  free(B);
  free(C);
  return 0;
}
