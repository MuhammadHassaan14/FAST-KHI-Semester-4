#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/*Use Case for Mutex: A mutex is used when you want to ensure 
that only one thread at a time can modify a shared resource. 
Once a thread locks the mutex, other threads must wait until the mutex is unlocked*/

pthread_mutex_t mutex;  // Declare a mutex

void* thread_function(void* arg) {
    pthread_mutex_lock(&mutex);  // Lock the mutex before entering the critical section

    // Critical section: shared resource modification
    printf("Thread %ld is accessing the shared resource\n", pthread_self());
    // Simulate some work
    sleep(1);

    pthread_mutex_unlock(&mutex);  // Unlock the mutex after exiting the critical section

    return NULL;
}

int main() {
    pthread_t threads[5];

    // Initialize the mutex
    pthread_mutex_init(&mutex, NULL);

    // Create multiple threads
    for (int i = 0; i < 5; i++) {
        pthread_create(&threads[i], NULL, thread_function, NULL);
    }

    // Wait for all threads to finish
    for (int i = 0; i < 5; i++) {
        pthread_join(threads[i], NULL);
    }

    // Destroy the mutex
    pthread_mutex_destroy(&mutex);

    return 0;
}
