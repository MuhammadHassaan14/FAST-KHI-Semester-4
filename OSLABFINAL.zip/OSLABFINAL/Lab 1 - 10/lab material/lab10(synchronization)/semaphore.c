#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

/*Use Case for Semaphore: Semaphores are often used when you need to control access 
to a limited number of resources (like a fixed number of database connections, printers, etc.) 
where multiple threads might need access concurrently but only a limited number at a time.*/

sem_t chairs;  // Semaphore for controlling access to chairs

// Thread function where each person tries to sit and work
void* person(void* arg) {
    int id = *(int*)arg;  // Cast the argument to an integer (person's ID)
    printf("Person %d is waiting for a chair.\n", id);

    // Wait (decrement) the semaphore (try to sit)
    sem_wait(&chairs);

    // Critical section: sit on the chair (do some work)
    printf("Person %d has taken a chair and is sitting.\n", id);
    sleep(1);  // Simulate some work (sitting and working)

    // Signal (increment) the semaphore (stand up and leave)
    sem_post(&chairs);

    printf("Person %d has stood up and left the chair.\n", id);

    return NULL;
}
// in this code, two threads can enter the critical section at the same time.

int main() {
    pthread_t threads[5];
    int ids[5];  // Array of IDs for persons (1 to 5)

    // Initialize the semaphore to allow only 2 people to sit at the same time
    sem_init(&chairs, 0, 2);

    // Create 5 threads (representing 5 people)
    for (int i = 0; i < 5; i++) {
        ids[i] = i + 1;  // Set ID for each person (1 to 5)
        pthread_create(&threads[i], NULL, person, &ids[i]);  // Pass the ID to the thread
    }

    // Wait for all threads to finish
    for (int i = 0; i < 5; i++) {
        pthread_join(threads[i], NULL);
    }

    // Destroy the semaphore after use
    sem_destroy(&chairs);

    return 0;
}
