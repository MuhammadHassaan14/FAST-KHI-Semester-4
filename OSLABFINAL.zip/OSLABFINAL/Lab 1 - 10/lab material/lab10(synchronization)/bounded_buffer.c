/*What is the Bounded Buffer Problem?
The Bounded Buffer Problem (or Producer-Consumer Problem) involves two types of threads (or processes):

Producers: Threads that generate data and insert it into a shared buffer.

Consumers: Threads that take data from the shared buffer.

The buffer has a fixed (bounded) size, 
so producers must wait if the buffer is full,
 and consumers must wait if the buffer is empty.
You need synchronization mechanisms (like mutexes and semaphores) to ensure proper coordination between producers and consumers.

*/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFFER_SIZE 5  // Size of the bounded buffer
int buffer[BUFFER_SIZE];  // The shared buffer
int in = 0;  // Index for the next item to be produced
int out = 0;  // Index for the next item to be consumed

// Semaphores for synchronization
sem_t empty;  // Semaphore to count the number of empty slots
sem_t full;   // Semaphore to count the number of full slots
sem_t mutex;  // Semaphore for mutual exclusion when accessing the buffer

// Producer thread function
void* producer(void* arg) {
    int item;
    while (1) {
        // Produce an item (simple example: a random number)
        item = rand() % 100;
        printf("Producer is producing: %d\n", item);

        // Wait until there's space in the buffer
        sem_wait(&empty);
        printf("Producer is waiting for an empty slot.\n");

        // Enter critical section to add the item to the buffer
        sem_wait(&mutex);
        buffer[in] = item;  // Place the item in the buffer
        printf("Producer has placed %d in the buffer at position %d.\n", item, in);
        in = (in + 1) % BUFFER_SIZE;

        // Leave critical section
        sem_post(&mutex);

        // Signal that a new item has been added
        sem_post(&full);
        printf("Producer has added %d to the buffer. Items in buffer: %d/%d\n", item, (in - out + BUFFER_SIZE) % BUFFER_SIZE, BUFFER_SIZE);

        sleep(1);  // Simulate some delay
    }
    return NULL;
}

// Consumer thread function
void* consumer(void* arg) {
    int item;
    while (1) {
        // Wait until there are items to consume
        sem_wait(&full);
        printf("Consumer is waiting for an item to consume.\n");

        // Enter critical section to remove the item from the buffer
        sem_wait(&mutex);
        item = buffer[out];  // Get the item from the buffer
        printf("Consumer has taken %d from the buffer at position %d.\n", item, out);
        out = (out + 1) % BUFFER_SIZE;

        // Leave critical section
        sem_post(&mutex);

        // Signal that there's space in the buffer
        sem_post(&empty);
        printf("Consumer has consumed %d. Items in buffer: %d/%d\n", item, (in - out + BUFFER_SIZE) % BUFFER_SIZE, BUFFER_SIZE);

        sleep(1);  // Simulate some delay
    }
    return NULL;
}

int main() {
    pthread_t prod, cons;

    // Initialize semaphores
    sem_init(&empty, 0, BUFFER_SIZE);  // Initially, all slots are empty
    sem_init(&full, 0, 0);  // No items are in the buffer initially
    sem_init(&mutex, 0, 1);  // Mutex is initially available

    // Create producer and consumer threads
    pthread_create(&prod, NULL, producer, NULL);
    pthread_create(&cons, NULL, consumer, NULL);

    // Wait for threads to finish (they won't finish in this infinite loop)
    pthread_join(prod, NULL);
    pthread_join(cons, NULL);

    // Destroy semaphores after use
    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&mutex);

    return 0;
}
