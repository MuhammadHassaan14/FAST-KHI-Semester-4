/*The Reader-Writer Problem is a classic synchronization problem where we have two types of processes:

Readers: Processes that only read the data.

Writers: Processes that modify the data.

The goal is to allow multiple readers to read the data simultaneously, but writers need exclusive access to the data. If a writer is writing, no readers or other writers should be allowed to access the data. Similarly, if a reader is reading, other readers can read but no writers should be allowed to write.

The problem arises when there is a need to synchronize the access to shared data, using semaphores or mutexes to ensure the proper order of access.

Conditions:
1. Multiple readers can read simultaneously, but no writer can access the data when any reader is reading.

2. Writers get exclusive access: If a writer is writing, no reader or other writer can access the data.

3. Writer starvation: Ideally, we should prevent writer starvation (i.e., writers should eventually be able to write).*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t mutex;        // Mutex for critical section
sem_t write_lock;   // Semaphore for writers to get exclusive access
int read_count = 0; // Counter for the number of readers

// Reader thread function
void *reader(void *arg)
{
    int id = *(int *)arg;

    // Start reading
    sem_wait(&mutex); // Enter critical section to update read count
    read_count++;
    if (read_count == 1)
    {
        printf("Reader %d is the first reader, blocking writers.\n", id);
        sem_wait(&write_lock); // Block writers when the first reader starts
    }
    sem_post(&mutex);

    // Reading section
    printf("Reader %d is reading\n", id);
    sleep(1); // Simulate reading

    // End reading
    sem_wait(&mutex); // Enter critical section to update read count
    read_count--;
    if (read_count == 0)
    {
        printf("Reader %d is the last reader, allowing writers.\n", id);
        sem_post(&write_lock); // Allow writers if no readers are reading
    }
    sem_post(&mutex);

    return NULL;
}

// Writer thread function
void *writer(void *arg)
{
    int id = *(int *)arg;

    // Start writing
    printf("Writer %d is waiting to write.\n", id);
    sem_wait(&write_lock); // Get exclusive access for writing

    // Writing section
    printf("Writer %d is writing\n", id);
    sleep(2); // Simulate writing

    // End writing
    printf("Writer %d has finished writing.\n", id);
    sem_post(&write_lock); // Release write lock

    return NULL;
}

int main()
{
    pthread_t readers[5], writers[3];
    int reader_ids[5] = {1, 2, 3, 4, 5};
    int writer_ids[3] = {1, 2, 3};

    // Initialize semaphores
    sem_init(&mutex, 0, 1);      // Mutex for managing read count
    sem_init(&write_lock, 0, 1); // Semaphore to control writers' access

    // Create reader threads
    for (int i = 0; i < 5; i++)
    {
        pthread_create(&readers[i], NULL, reader, &reader_ids[i]);
    }

    // Create writer threads
    for (int i = 0; i < 3; i++)
    {
        pthread_create(&writers[i], NULL, writer, &writer_ids[i]);
    }

    // Wait for threads to finish
    for (int i = 0; i < 5; i++)
    {
        pthread_join(readers[i], NULL);
    }
    for (int i = 0; i < 3; i++)
    {
        pthread_join(writers[i], NULL);
    }

    // Destroy semaphores
    sem_destroy(&mutex);
    sem_destroy(&write_lock);

    return 0;
}
