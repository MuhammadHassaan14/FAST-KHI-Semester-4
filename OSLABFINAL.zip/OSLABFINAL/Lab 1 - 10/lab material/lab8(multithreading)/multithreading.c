

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// Define a structure to pass multiple arguments to threads
typedef struct {
    int thread_id;
    int data;
    // Add more fields as needed
} ThreadArgs;

// Thread function
void *thread_func(void *arg) {
    ThreadArgs *args = (ThreadArgs *)arg;

    // Simulate work
    printf("Thread %d started with data = %d\n", args->thread_id, args->data);
    sleep(1); // simulate delay
    printf("Thread %d finished\n", args->thread_id);

    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    int n_threads = 4; // Change this as needed
    pthread_t threads[n_threads];
    ThreadArgs args[n_threads];

    // Create threads
    for (int i = 0; i < n_threads; i++) {
        args[i].thread_id = i;
        args[i].data = i * 10;  // Sample data
        if (pthread_create(&threads[i], NULL, thread_func, &args[i]) != 0) {
            perror("pthread_create");
            exit(EXIT_FAILURE);
        }
    }

    // Wait for all threads to finish
    for (int i = 0; i < n_threads; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            perror("pthread_join");
            exit(EXIT_FAILURE);
        }
    }

    printf("All threads completed.\n");
    return 0;
}
