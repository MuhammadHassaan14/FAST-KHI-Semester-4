#include <stdio.h>
#include "bar.h"

void bar_function() {
    printf("This is bar_function()\n");
}
