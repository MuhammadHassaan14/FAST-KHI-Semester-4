#ifndef FOO_H
#define FOO_H

void foo_function();

#endif
