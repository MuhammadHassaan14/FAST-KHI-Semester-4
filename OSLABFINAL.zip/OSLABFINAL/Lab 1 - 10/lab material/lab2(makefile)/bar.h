#ifndef BAR_H
#define BAR_H

void bar_function();

#endif
