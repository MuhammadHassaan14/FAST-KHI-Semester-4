#include <stdio.h>
#include "foo.h"

void foo_function() {
    printf("This is foo_function()\n");
}
