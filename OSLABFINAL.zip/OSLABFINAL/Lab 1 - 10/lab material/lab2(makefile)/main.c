#include <stdio.h>
#include "foo.h"
#include "bar.h"

int main() {
    foo_function();
    bar_function();
    return 0;
}
