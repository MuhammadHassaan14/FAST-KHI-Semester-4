#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

int main()
{
    int fd = open("fifo", O_RDONLY);
    char buffer[100];
    while (1)
    {
        int bytes = read(fd, buffer, sizeof(buffer) - 1);
        if (bytes <= 0)
            break;
        if (strcmp(buffer, "exit\n") == 0)
            break;
        buffer[bytes] = '\0'; // null terminate
        printf("Recieved: %s", buffer);
    }
    close(fd);
    unlink("fifo");
}