#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
int main()
{
    // first make the pipe using mkfifo
    mkfifo("fifo", 0666);
    // this is the producer file so we write into the pipe (send the data)
    int fd = open("fifo", O_WRONLY);
    char buffer[100];

    // reading the user input till the user writes "exit"
    while (1)
    {
        printf("Enter a message to send ('exit' to quite)\n");
        fgets(buffer, 100, stdin);

        if (strcmp(buffer, "exit\n") == 0)
            break;
        int bytes = write(fd, buffer, strlen(buffer));
        if (bytes <= 0)
            break;
    }

    close(fd);
}
