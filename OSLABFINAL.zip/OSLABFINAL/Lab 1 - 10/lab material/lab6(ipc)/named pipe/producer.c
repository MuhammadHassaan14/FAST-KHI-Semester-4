#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

int main()
{
    // first make a named pipe

    mkfifo("fifo", 0666);
        
    
    // This is the producer code so we have to open the pipe in the write mode
    int fd = open("fifo", O_WRONLY);
    write(fd, "Your abbu", 9);
    
    close(fd);
}