#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

int main()
{
    char buffer[9];
    printf("Reader: Opening FIFO for reading\n");
    int fd = open("fifo", O_RDONLY);
    read(fd, buffer, sizeof(buffer));
    
    printf("No %s", buffer);
    printf("\n");
    close(fd);
    unlink("fifo");
}