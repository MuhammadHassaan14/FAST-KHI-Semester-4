#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

void reverseArray(char arr[], int n) {
    for (int i = 0; i < n / 2; i++) {
        char temp = arr[i];
        arr[i] = arr[n - i - 1];
        arr[n - i - 1] = temp;
    }
}

int main() {
    int fd[2];
    pipe(fd);
  
    int pid = fork();
    if (pid > 0) {  // Parent Process
        close(fd[0]);  // Close unused read end
        char buffer[1024];
        printf("Write a string to reverse:\n");
        fgets(buffer, 1024, stdin);

        buffer[strcspn(buffer, "\n")] = 0;  // Remove newline

        write(fd[1], buffer, strlen(buffer) + 1);
        close(fd[1]);
        wait(NULL);
    } else {  // Child Process
        char buffer[1024];
        close(fd[1]);  // Close unused write end
        read(fd[0], buffer, sizeof(buffer));
        close(fd[0]);

        int len = strlen(buffer);
        reverseArray(buffer, len);  // Reverse the string
        printf("Reversed string: %s\n", buffer);
    }

    return 0;
}
