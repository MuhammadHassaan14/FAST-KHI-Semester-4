#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main()
{
    int fd[2]; // fd[0]: read end, fd[1]: write end
    pipe(fd);

    int pid = fork();
    if (pid > 0)
    {   wait(NULL);
        close(fd[0]); // closing the read end

        char buffer[1024];
        printf("Enter a linux command:\n");
        fgets(buffer, 1024, stdin);
        buffer[strlen(buffer) - 1] = '\0';
        write(fd[1], buffer, strlen(buffer) + 1);

        close(fd[1]);
        
    }
    else
    {
        close(fd[1]);
        char command[1024];
        read(fd[0], command, sizeof(command));
        close(fd[0]);
        printf("Executing command: %s\n", command);
        execlp("/bin/sh","sh","-c",command, NULL);
    }
}