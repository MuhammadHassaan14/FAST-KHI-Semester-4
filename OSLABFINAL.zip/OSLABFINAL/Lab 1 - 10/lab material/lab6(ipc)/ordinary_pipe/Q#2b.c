#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
int palindrome(char *str,int n){
    for(int i=0;i<n/2;i++){
        if(str[i]!=str[n-i-1])
            return 0;
    }
    return 1;
}
int main(){
    int fd1[2]; //fd[0] for reading and fd[1] for writing
    int fd2[2];
    pipe(fd1);
    pipe(fd2);
    int pid=fork();
    if(pid>0){
        close(fd1[0]); // close the unused reading end of the first pipe
        char str[50];
        printf("Enter a string:\n");
        fgets(str,50,stdin);
        str[strlen(str)-1]='\0';
        write(fd1[1],str,sizeof(str));
        close(fd1[1]); 

        char receive[50];
        close(fd2[1]); // close the unused write end of the second pipe
        read(fd2[0],receive,sizeof(receive));
        printf("%s",receive);
        
        close(fd2[0]);
        
        printf("No of characters: %ld",strlen(str));
    }
    else if(pid==0){
        close(fd1[1]);
        char receive[50];
        int bytes =read(fd1[0],receive,sizeof(receive));
        receive[bytes]='\0';
        close(fd1[0]);
        char result[50];
        close(fd2[0]);
        if(palindrome(receive,bytes)){
            strcpy(result,"Palindrome\n");

        }
        else strcpy(result,"Not a Palindrome\n");
        write(fd2[1],result,sizeof(result));
        close(fd2[1]);
    }
}