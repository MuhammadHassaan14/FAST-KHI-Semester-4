#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

int main(int argc, char* argv[]){
    int fd[2];
    pipe(fd);
    int pid= fork();
    if(pid>0){
        char buffer[1024];
        int source_fd=open(argv[1],O_RDONLY);
        close(fd[0]);
        int bytes;
        while((bytes=read(source_fd,buffer,1024))>0)
            write(fd[1],buffer,bytes);
        close(source_fd);
        close(fd[1]);
        wait(NULL);
    }
    else{
        close(fd[1]);
        int dest_fd=open(argv[2],O_WRONLY);
        char buffer[1024];
        int bytes;
        while((bytes=read(fd[0],buffer,1024))>0)
            write(dest_fd,buffer,bytes);

        close(dest_fd);
        close(fd[0]);

    }
}