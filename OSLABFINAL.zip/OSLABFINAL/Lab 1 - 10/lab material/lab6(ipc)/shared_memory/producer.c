#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define SIZE 4096 // Size of shared memory
#define NAME "OS" // Shared memory name

int main()
{
    int fd;    // Shared memory file descriptor
    char *ptr; // Pointer to shared memory

    // Create the shared memory object
    fd = shm_open(NAME, O_CREAT | O_WRONLY, 0666);
    if (fd == -1)
    {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }

    // Set the size of shared memory
    ftruncate(fd, SIZE);

    // Map the shared memory object
    ptr = (char *)mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED)
    {
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    // Write messages to shared memory
    sprintf(ptr, "Hello ");
    ptr += strlen("Hello ");
    sprintf(ptr, "World!");

    printf("Producer: Written to shared memory\n");

    return 0;
}
