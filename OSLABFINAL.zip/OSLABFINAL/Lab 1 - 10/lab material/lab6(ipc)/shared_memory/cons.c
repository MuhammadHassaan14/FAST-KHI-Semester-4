#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define SIZE 4096
#define NAME "OS"

int main() {
    int fd;
    int *ptr;

    // Open shared memory object
    fd = shm_open(NAME, O_RDONLY, 0666);
    if (fd == -1) {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }

    // Map shared memory
    ptr = (int *)mmap(0, SIZE, PROT_READ, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED) {
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    // Read the number of elements
    int count = *ptr;
    ptr++; // Move pointer to the array part

    // Read array and compute sum
    int sum = 0;
    printf("Consumer: Received array: ");
    for (int i = 0; i < count; i++) {
        printf("%d ", ptr[i]);
        sum += ptr[i];
    }
    printf("\nSum of array: %d\n", sum);

    // Cleanup shared memory
    shm_unlink(NAME);
    munmap(ptr, SIZE);
    close(fd);

    return 0;
}
