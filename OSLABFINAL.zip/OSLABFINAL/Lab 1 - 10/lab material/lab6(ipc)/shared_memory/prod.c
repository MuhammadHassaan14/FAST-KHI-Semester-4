#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

#define SIZE 4096
#define NAME "OS"

int main() {
    int fd;
    int *ptr;
    int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // Array to send
    int count = sizeof(numbers) / sizeof(numbers[0]); // Number of elements

    // Create shared memory object
    fd = shm_open(NAME, O_CREAT | O_RDWR, 0666);
    if (fd == -1) {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }

    // Set the size of shared memory
    ftruncate(fd, SIZE);

    // Map shared memory
    ptr = (int *)mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED) {
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    // Write the number of elements first
    *ptr = count;
    ptr++; // Move pointer ahead

    // Write array into shared memory
    for (int i = 0; i < count; i++) {
        *ptr = numbers[i];
        ptr++;
    }

    printf("Producer: Sent array to shared memory.\n");

    // Close memory
    munmap(ptr, SIZE);
    close(fd);

    return 0;
}
