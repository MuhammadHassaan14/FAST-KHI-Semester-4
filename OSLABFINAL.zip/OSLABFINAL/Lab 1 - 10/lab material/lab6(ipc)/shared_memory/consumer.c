#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define SIZE 4096 // Size of shared memory
#define NAME "OS" // Shared memory name

int main()
{
    int fd;    // Shared memory file descriptor
    char *ptr; // Pointer to shared memory

    // Open the shared memory object
    fd = shm_open(NAME, O_RDONLY, 0666);
    if (fd == -1)
    {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }

    // Map the shared memory object
    ptr = (char *)mmap(0, SIZE, PROT_READ, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED)
    {
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    // Read from shared memory
    printf("Consumer received: %s\n", ptr);

    // Remove shared memory
    shm_unlink(NAME);

    return 0;
}
