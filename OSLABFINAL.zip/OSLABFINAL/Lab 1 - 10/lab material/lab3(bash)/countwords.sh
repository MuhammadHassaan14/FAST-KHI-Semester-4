#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

# Usage check
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <filename>"
  exit 1
fi

file="$1"

# 1. Test if it’s a regular file
if [ ! -f "$file" ]; then
  echo "Error: '$file' is not a regular file."
  exit 1
fi

# 2. Count the words
word_count=$(wc -w "$file")

# 3. Display the result
echo "Total words in '$file': $word_count"
