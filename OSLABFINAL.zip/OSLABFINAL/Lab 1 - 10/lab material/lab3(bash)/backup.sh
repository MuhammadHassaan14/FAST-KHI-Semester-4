#!/bin/bash

#first check if the there are 2 command line inputs
if [ "$#" -ne 2 ]; then
    echo "provide correct input in commandline"
    exit 1
fi
src_dir="$1"
dest_dir="$2"

#check if the source directory exists
if [ ! -d "$src_dir" ]; then
echo "source directory '$src_dir' not found"
exit 1
fi

#check if the destination directory exists if not then create one with
# with the provided name.

if [ ! -d "$dest_dir" ]; then

mkdir -p "$dest_dir"
fi

# now copy everything from the source directory to the destnation.

cp -r "$src_dir/"* "$dest_dir" # recursively copy every file from source dirctory to destination directory

echo "Backup done"
