#!/bin/bash
echo "Enter a directory name:"
read dir

if [ ! -d "$dir" ];then
echo "Directory doesn't exist."
exit 1
fi

count=$(ls -1 "$dir" | wc -l)

echo "$count"

