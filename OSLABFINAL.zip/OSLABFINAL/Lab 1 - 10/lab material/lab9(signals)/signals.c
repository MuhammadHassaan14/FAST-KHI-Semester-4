#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void signal_handler(int sig)
{   printf("Signal received.\n");
    // cleanup for the task when Ctrl+c is recieved
    // fclose(),etc
    
    exit(0);
}

int main()
{
    signal(SIGINT, signal_handler); // SIGINT is checking Ctrl+c
    // when Ctrl+c is sent then signal_handler function is executed.

    printf("performing task until a signal is received.\n");

    while (1)
    {
        // do any task

        sleep(1); // Wait for signal for 1 second before continuing task
    }

    return 0;
}
