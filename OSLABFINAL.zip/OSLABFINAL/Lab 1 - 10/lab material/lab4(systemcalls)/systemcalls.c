// syscalls_demo.c

// Header files providing system call declarations:
// <fcntl.h>      → open()
// <unistd.h>     → read(), write(), close(), fork(), execl()
// <sys/types.h>  → pid_t
// <sys/wait.h>   → waitpid()
// <stdio.h>      → perror(), printf()
// <stdlib.h>     → exit(), EXIT_FAILURE, EXIT_SUCCESS
// <string.h>     → strlen()

#include <stdio.h>      // perror(), printf()
#include <stdlib.h>     // exit(), EXIT_FAILURE, EXIT_SUCCESS
#include <unistd.h>     // read(), write(), close(), fork(), execl()
#include <fcntl.h>      // open()
#include <sys/types.h>  // pid_t
#include <sys/wait.h>   // waitpid()
#include <string.h>     // strlen()

int main(int argc, char *argv[]) {
    const char *filename = "demo.txt";
    const char *message = "Hello from syscalls_demo!\n";

    // 1. open() and write()
    int fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    if (write(fd, message, strlen(message)) < 0) {
        perror("write");
        close(fd);
        exit(EXIT_FAILURE);
    }

    close(fd);

    // 2. fork() and execl()
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child process: execute 'wc -l demo.txt'
        execl("/usr/bin/wc", "wc", "-l", filename, (char *)NULL);
    
        /*
          execl("/usr/bin/wc", "wc", "-l", filename, (char *)NULL);
    
          - "/usr/bin/wc": path to the 'wc' program (line/word count tool).
          - "wc": argv[0], the name of the program as seen by itself.
          - "-l": argv[1], tells wc to count only lines.
          - filename: argv[2], the file to operate on (e.g., "demo.txt").
          - (char *)NULL: marks the end of the argument list for execl.
    
          This replaces the child process with `wc -l demo.txt`.
          If execl fails, the code below will run (which should not happen).
        */
    
        perror("execl");
        _exit(EXIT_FAILURE);
    }
     else {
        // Parent process: wait for child to complete
        int status;
        if (waitpid(pid, &status, 0) < 0) {
            perror("waitpid");
            exit(EXIT_FAILURE);
        }

        if (WIFEXITED(status)) {
            printf("Child exited with code %d\n", WEXITSTATUS(status));
        } else {
            printf("Child terminated abnormally\n");
        }
    }

    return EXIT_SUCCESS;
}
